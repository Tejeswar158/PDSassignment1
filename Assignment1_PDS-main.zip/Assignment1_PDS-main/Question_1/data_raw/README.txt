This is a sample text file.
